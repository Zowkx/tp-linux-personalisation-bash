#Script principale qui appel les fonctions des autres fichiers

#Source des fichiers
for file in ./fonctions/*.sh; do
	[ -f "$file" ] && . "$file"
done

message_bienvenue
check_sudo
check_internet
echo "Mise à jour de la machine..."
apt update >> /dev/null
apt upgrade -y >> /dev/null

cp_cle
Durcissement_ssh
Config_fw

set_google_auth
Modif_shell
create_alias

echo "Le script est terminé veuillez redémarrer.."
