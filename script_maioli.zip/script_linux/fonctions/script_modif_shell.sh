#!/bin/bash

Modif_shell() {
	echo "Modification du shell"
    	#Modifie le shell pour le personalisé et rend les modifs permanente
	#On récupère le path home de l'utilisateur qui a lancé le script
	home_user=$(eval echo "~$SUDO_USER")
	echo "export PS1='\\[\\e[34m\\]\\u@\\h \\[\\e[33m\\][\\w] \\[\\e[32m\\]\\t \\[\\e[0m\\]\\$ '" >> "$home_user/.bashrc"
}
