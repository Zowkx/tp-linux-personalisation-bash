#!/bin/bash

#La fonction vérifie si le script est bien exécuté en tant qu'administrateur
#Si il ne l'ai pas, il quitte le script
check_sudo() {
if sudo -n true 2>/dev/null; then
        echo "Droit sudo accordé, exécution du script"
else
        echo "Les droits sudo sont requis pour exécuter ce script"
        exit 1
fi
}
