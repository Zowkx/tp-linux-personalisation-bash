#!/bin/bash


create_alias(){
	echo "Creation d'alias"
	user_home=$(eval echo "~$SUDO_USER")

	echo "alias update='sudo apt update && sudo apt upgrade -y'" >> "$user_home/.bashrc"
	echo "alias co='ssh enzo@10.0.2.4'" >> "$user_home/.bashrc"
}
