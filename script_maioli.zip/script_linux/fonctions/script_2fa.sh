#!/bin/bash

set_google_auth(){
	apt install -y libpam-google-authenticator >> /dev/null
	
	read -p "Pour quel utilisateur voulez vous activer le MFA? : " utilisateur
	sudo -u "$utilisateur" google-authenticator -t -d -f -r 3 -R 30 -w 1
	
	echo "Mise en place de google auth"
	echo "auth required pam_google_authenticator.so" >> /etc/pam.d/sshd
	sed -i 's/^#\(ChallengeResponseAuthentication\) .*/\1 yes/' /etc/ssh/sshd_config
	sed -i 's/^#\(UsePAM\) .*/\1 yes/' /etc/ssh/sshd_config
	echo "Double auth configuré"
}
