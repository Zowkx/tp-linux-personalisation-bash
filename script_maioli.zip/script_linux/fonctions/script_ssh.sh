#!/bin/bash

#Copie de la clé publique
cp_cle(){
	#Copie la clé sur la machine de manière sécurisé
	user_home=$(eval echo "~$SUDO_USER")
	mkdir -p "$user_home/.ssh"
	cat ./id_rsa.pub >>"$user_home/.ssh/authorized_keys"
}


#Renforce la sécurité de ssh
Durcissement_ssh() {
	echo "Modification des fichiers de configuration ssh"
	#Modifie les fichiers de configuration pour améliorer la sécurité de ssh
	sed -i 's/#PasswordAuthentication yes/PasswordAuthentication no/' /etc/ssh/sshd_config
	sed -i 's/#PermitRootLogin yes/PermitRootLogin no/' /etc/ssh/sshd_config
	#Demande sur quel port ssh doit être mapper
	sed -i 's/#Port 22/Port 2101/' /etc/ssh/sshd_config
	echo "Port SSH modifier sur le port 2101"
	echo "Fichier de configuration modifier"
	#Demande à l'utilisateur si il veut restreindre l'accès ssh à certain utilisateur
	read -p "Voulez vous restreindre l'accès à ssh à certains utilisateurs ?(y/n)" appro
	case "$appro" in
		[Yy])
			#Crée le groupe userssh qui sera utilisé pour "whitelist" les utilisateurs
			if groupadd userssh; then
		                echo "Le groupe userssh a été créer avec succès"
        		else
        		        echo "Le groupe userssh n'a pas pu être créer"
               			 exit 1
			fi

			read -p "Entrez le nom d'utilisateur à autoriser : " user
			#Rajoute l'utilisateur au groupe userssh et au fichier de config pour l'autoriser
			#à se connecter, pareil avec le group userssh
			if usermod -aG userssh "$user"; then
				echo "L'utilisateur a été rajouter avec succès"
				permituser="AllowUsers $user "
				echo "AllowGroups userssh" >> /etc/ssh/sshd_config
			else
				echo "L'utilisateur n'a pas pu être ajouter"
				exit 1
			fi
			#Boucle pour rajouter des utilisateurs supplémentaires (pour éviter de rajouter 
			#"AllowUsers" deux fois)
			while true; do
				read -p "Voulez vous rajouter un autre utilisateur(y/n) ?" adduser
				#Vérifie chaque cas, si l'utilisateur tape autre chose que ce qui est attendu
				#le script boucle pour lui demander
				case "$adduser" in
					[Yy])
						read -p "Entrez le nom d'utilisateur à autoriser : " user1
						if usermod -aG userssh "$user1"; then
							echo "L'utilisateur a été rajouter avec succès"
							permituser+="$user1 " #Espace si d'autre user
						else
							echo "L'utilisateur n'a pas pu être ajouter"
							exit 1
						fi ;;
					[Nn])
						break ;;
					*)
						echo "Veuillez répondre par y ou n" ;;
				esac
			done
			echo "$permituser" >> /etc/ssh/sshd_config
		;;
		[Nn])
			echo "Aucune restriction sur les utilisateurs a été mis en place" ;;
		*)
			echo "Veuillez répondre par y ou n" ;;
		esac
	continue="true"
	keeep="true"
	while [ "$keeep" = "true" ]; do
		read -p "Voulez-vous établir une whitelist d'adresse IP (y/n)?  " apro
		case "$apro" in
			[Yy])
				keeep="false"
				while [ "$continue" = "true" ]; do
				read -p "Entrer l'adresse IP que vous voulez whitelist: " ip
				echo "sshd: $ip" >> /etc/hosts.allow
					while true; do
						read -p "Voulez vous rajouter une autre adresse IP? (y/n) : " add
						case "$add" in
							[Yy])
								break
								;;
							[Nn])
								echo "sshd: ALL" >> /etc/hosts.deny
								continue="false"
								break
						       		break
								;;
							*)
								echo "Veuillez répondre par y ou n" ;;
						esac
					done
				done
				;;
			[Nn])
				echo "Aucune whitelist d'adresse IP n'a été mise en place"
			       	break	;;
			*)
				echo "Veuillez répondre par y/n" ;;
			esac
		done
	systemctl restart ssh
}

