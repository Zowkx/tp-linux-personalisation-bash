#!/bin/bash

#Envoie un ping au DNS de google et vérifie le code retour
#en cas d'échec du ping, le script s'arrête
check_internet() {
	if ping -c 1 8.8.8.8 > /dev/null; then
		echo "Accès internet validé"
	else
		echo "Pas d'accès internet, abandon du script..."
		exit 1
	fi
}
