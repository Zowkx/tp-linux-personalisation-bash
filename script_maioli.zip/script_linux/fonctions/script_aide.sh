#!/bin/bash

config_aide() {
	echo "Installation de AIDE"

	#Installation de aide
	apt install -y aide
	
	#Initialisation de la bdd
	aide --init --config=/etc/aide/aide.conf
	
	#Rename de la bdd
	mv /var/lib/aide/aide.db.new /var/lib/aide/aide.db
	aide --check

	echo "Aide installé"
}
