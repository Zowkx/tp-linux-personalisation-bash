#!/bin/bash
#Configuration du pare-feu
Config_fw() {
	#Install le fw (-y de tout accepter et je redirige le reste vers /dev/null pour pas avoir
	#des affichages parasites sur le shell
	apt install -y ufw > /dev/null
	#Ouvre les ports fréquents
        ufw allow 80
        ufw allow 443
        ufw allow 2101
	#Active le firewall
        ufw enable
}

